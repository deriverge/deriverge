/* Settings page of Deriverge Job Feed Importer: "Run now" in short batches, with progress. */
( function () {
	'use strict';
	var cfg = window.djfiAdmin;
	if ( ! cfg ) {
		return;
	}

	function fmt( template, values ) {
		return template.replace( /%(\d)\$s/g, function ( m, i ) {
			return String( values[ Number( i ) - 1 ] );
		} );
	}

	function setStatus( feed, text ) {
		var el = document.querySelector( '.djfi-status[data-feed="' + feed + '"]' );
		if ( el ) {
			el.textContent = text;
		}
	}

	function step( feed, button, start ) {
		var body = new URLSearchParams();
		body.set( 'action', 'djfi_step' );
		body.set( 'nonce', cfg.nonce );
		body.set( 'feed', feed );
		if ( start ) {
			body.set( 'start', '1' );
		}
		fetch( cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( r ) {
				return r.json();
			} )
			.then( function ( res ) {
				var s = res && res.data;
				if ( ! res || ! res.success || ! s ) {
					setStatus( feed, ( s && s.message ) || cfg.i18n.network );
					button.disabled = false;
					return;
				}
				if ( s.phase === 'error' ) {
					setStatus( feed, cfg.i18n.failed + ' ' + s.error );
					button.disabled = false;
					return;
				}
				if ( s.phase === 'done' ) {
					setStatus( feed, fmt( cfg.i18n.done, [ s.read, s.created, s.updated, s.same, s.closed ] ) );
					button.disabled = false;
					return;
				}
				setStatus( feed, s.phase === 'cleanup' ? cfg.i18n.closing : fmt( cfg.i18n.progress, [ s.read, s.created, s.updated ] ) );
				window.setTimeout( function () {
					step( feed, button, false );
				}, 300 );
			} )
			.catch( function () {
				setStatus( feed, cfg.i18n.network );
				button.disabled = false;
			} );
	}

	document.addEventListener( 'click', function ( e ) {
		var run = e.target.closest ? e.target.closest( '.djfi-run' ) : null;
		if ( run ) {
			e.preventDefault();
			run.disabled = true;
			setStatus( run.getAttribute( 'data-feed' ), cfg.i18n.starting );
			step( run.getAttribute( 'data-feed' ), run, true );
			return;
		}
		var sample = e.target.closest ? e.target.closest( '#djfi-sample' ) : null;
		if ( sample ) {
			e.preventDefault();
			var url = document.getElementById( 'djfi-url' );
			var name = document.getElementById( 'djfi-name' );
			if ( url ) {
				url.value = sample.getAttribute( 'data-url' );
			}
			if ( name && ! name.value ) {
				name.value = 'Sample feed';
			}
		}
	} );
} )();
