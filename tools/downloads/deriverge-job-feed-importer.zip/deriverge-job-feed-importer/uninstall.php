<?php
/**
 * Removes the plugin's settings. Imported job listings stay, they belong to the site.
 *
 * @package Deriverge_Job_Feed_Importer
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$djfi_settings = get_option( 'djfi_settings', array() );
if ( is_array( $djfi_settings ) && ! empty( $djfi_settings['feeds'] ) && is_array( $djfi_settings['feeds'] ) ) {
	foreach ( array_keys( $djfi_settings['feeds'] ) as $djfi_feed_id ) {
		delete_option( 'djfi_state_' . $djfi_feed_id );
	}
}
delete_option( 'djfi_settings' );
delete_option( 'djfi_log' );
wp_clear_scheduled_hook( 'djfi_cron' );
wp_clear_scheduled_hook( 'djfi_continue' );
