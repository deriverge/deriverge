<?php
/**
 * Reads job feeds (XML, JSON Lines, JSON) in slices, so a large feed never has to fit in memory or in one request.
 *
 * @package Deriverge_Job_Feed_Importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Feed reader.
 */
class DJFI_Reader {

	/**
	 * Detects the format of a downloaded feed file.
	 *
	 * @param string $file Path.
	 * @return string xml, jsonl, json, gzip, html or unknown.
	 */
	public static function detect( $file ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local temp file, first bytes only.
		$head = (string) file_get_contents( $file, false, null, 0, 2048 );
		if ( strlen( $head ) >= 2 && "\x1f\x8b" === substr( $head, 0, 2 ) ) {
			return 'gzip';
		}
		$head = ltrim( preg_replace( '/^\xEF\xBB\xBF/', '', $head ) );
		if ( '' === $head ) {
			return 'unknown';
		}
		if ( '<' === $head[0] ) {
			return preg_match( '/^<(!doctype\s+html|html[\s>])/i', $head ) ? 'html' : 'xml';
		}
		if ( '[' === $head[0] ) {
			return 'json';
		}
		if ( '{' === $head[0] ) {
			return 'jsonl';
		}
		return 'unknown';
	}

	/**
	 * Unpacks a gzip file next to itself and returns the new path, or a WP_Error.
	 *
	 * @param string $file Path of the gzip file.
	 * @return string|WP_Error
	 */
	public static function gunzip( $file ) {
		if ( ! function_exists( 'gzopen' ) ) {
			return new WP_Error( 'djfi_gzip', __( 'The feed is gzip-compressed and this server cannot unpack it (zlib is missing).', 'deriverge-job-feed-importer' ) );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php'; // wp_tempnam() is not loaded during WP-Cron.
		$out = wp_tempnam( 'djfi-feed' );
		$in  = gzopen( $file, 'rb' );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streaming a temp file; WP_Filesystem has no stream API.
		$fp = fopen( $out, 'wb' );
		if ( ! $in || ! $fp ) {
			return new WP_Error( 'djfi_gzip', __( 'The compressed feed could not be unpacked.', 'deriverge-job-feed-importer' ) );
		}
		while ( ! gzeof( $in ) ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
			fwrite( $fp, (string) gzread( $in, 1 << 20 ) );
		}
		gzclose( $in );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $fp );
		return $out;
	}

	/**
	 * Reads up to $limit jobs starting at $offset.
	 *
	 * @param string $file   Path of the feed file.
	 * @param string $format xml, jsonl or json.
	 * @param int    $offset Job index (xml, json) or byte offset (jsonl).
	 * @param int    $limit  Maximum number of jobs.
	 * @return array{jobs:array<int,array<string,mixed>>,next:int,done:bool}|WP_Error
	 */
	public static function read( $file, $format, $offset, $limit ) {
		if ( 'xml' === $format ) {
			return self::read_xml( $file, $offset, $limit );
		}
		if ( 'jsonl' === $format ) {
			return self::read_jsonl( $file, $offset, $limit );
		}
		if ( 'json' === $format ) {
			return self::read_json( $file, $offset, $limit );
		}
		return new WP_Error( 'djfi_format', __( 'The address did not return an XML, JSON or JSON Lines job feed.', 'deriverge-job-feed-importer' ) );
	}

	/**
	 * XML feed with one <job> (or RSS <item>) element per job.
	 *
	 * @param string $file   Path.
	 * @param int    $offset Number of jobs to skip.
	 * @param int    $limit  Maximum number of jobs.
	 * @return array|WP_Error
	 */
	private static function read_xml( $file, $offset, $limit ) {
		if ( ! class_exists( 'XMLReader' ) || ! function_exists( 'simplexml_load_string' ) ) {
			return new WP_Error( 'djfi_xml', __( 'This server lacks the PHP XML extensions (XMLReader, SimpleXML). Use the JSON Lines address of the feed instead.', 'deriverge-job-feed-importer' ) );
		}
		$reader = new XMLReader();
		if ( ! $reader->open( $file, null, LIBXML_NONET | LIBXML_COMPACT ) ) {
			return new WP_Error( 'djfi_xml', __( 'The XML feed could not be opened.', 'deriverge-job-feed-importer' ) );
		}
		$tag = '';
		// phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition, WordPress.PHP.NoSilencedErrors.Discouraged -- malformed XML is reported below, not as PHP warnings.
		while ( @$reader->read() ) {
			if ( XMLReader::ELEMENT === $reader->nodeType && in_array( strtolower( $reader->localName ), array( 'job', 'item' ), true ) ) {
				$tag = $reader->localName;
				break;
			}
		}
		$jobs = array();
		$done = ( '' === $tag );
		for ( $i = 0; $i < $offset && ! $done; $i++ ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$done = ! @$reader->next( $tag );
		}
		while ( ! $done && count( $jobs ) < $limit ) {
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$xml = @$reader->readOuterXml();
			if ( '' !== $xml ) {
				$prev = libxml_use_internal_errors( true );
				$el   = simplexml_load_string( $xml, 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NONET );
				libxml_clear_errors();
				libxml_use_internal_errors( $prev );
				if ( $el ) {
					$row = array();
					foreach ( $el->children() as $child ) {
						$key = strtolower( $child->getName() );
						if ( ! isset( $row[ $key ] ) ) {
							$row[ $key ] = trim( (string) $child );
						}
					}
					$jobs[] = self::normalize( $row );
				}
			}
			++$offset;
			// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			$done = ! @$reader->next( $tag );
		}
		$reader->close();
		return array(
			'jobs' => $jobs,
			'next' => $offset,
			'done' => $done,
		);
	}

	/**
	 * JSON Lines: one JSON object per line; $offset is a byte position.
	 *
	 * @param string $file   Path.
	 * @param int    $offset Byte offset.
	 * @param int    $limit  Maximum number of jobs.
	 * @return array|WP_Error
	 */
	private static function read_jsonl( $file, $offset, $limit ) {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- reading a temp file line by line.
		$fp = fopen( $file, 'rb' );
		if ( ! $fp ) {
			return new WP_Error( 'djfi_jsonl', __( 'The feed file could not be opened.', 'deriverge-job-feed-importer' ) );
		}
		fseek( $fp, $offset );
		$jobs = array();
		$done = false;
		while ( count( $jobs ) < $limit ) {
			$line = fgets( $fp );
			if ( false === $line ) {
				$done = true;
				break;
			}
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$row = json_decode( $line, true );
			if ( is_array( $row ) ) {
				$jobs[] = self::normalize( array_change_key_case( $row, CASE_LOWER ) );
			}
		}
		$next = (int) ftell( $fp );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $fp );
		return array(
			'jobs' => $jobs,
			'next' => $next,
			'done' => $done,
		);
	}

	/**
	 * One JSON array of jobs (or an object with a jobs/items/data array).
	 *
	 * @param string $file   Path.
	 * @param int    $offset Index of the first job.
	 * @param int    $limit  Maximum number of jobs.
	 * @return array|WP_Error
	 */
	private static function read_json( $file, $offset, $limit ) {
		if ( filesize( $file ) > 40 * MB_IN_BYTES ) {
			return new WP_Error( 'djfi_json', __( 'This JSON feed is too large to read in one piece. Use the XML or JSON Lines address of the feed instead.', 'deriverge-job-feed-importer' ) );
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local temp file.
		$data = json_decode( (string) file_get_contents( $file ), true );
		if ( is_array( $data ) && ! isset( $data[0] ) ) {
			foreach ( array( 'jobs', 'items', 'data', 'results' ) as $key ) {
				if ( isset( $data[ $key ] ) && is_array( $data[ $key ] ) ) {
					$data = $data[ $key ];
					break;
				}
			}
		}
		if ( ! is_array( $data ) ) {
			return new WP_Error( 'djfi_json', __( 'The JSON feed could not be read.', 'deriverge-job-feed-importer' ) );
		}
		$data = array_values( $data );
		$jobs = array();
		foreach ( array_slice( $data, $offset, $limit ) as $row ) {
			if ( is_array( $row ) ) {
				$jobs[] = self::normalize( array_change_key_case( $row, CASE_LOWER ) );
			}
		}
		$next = $offset + $limit;
		return array(
			'jobs' => $jobs,
			'next' => $next,
			'done' => $next >= count( $data ),
		);
	}

	/**
	 * First non-empty value among several possible field names.
	 *
	 * @param array<string,mixed> $row  Feed row with lowercase keys.
	 * @param string[]            $keys Field names to try.
	 * @return string
	 */
	private static function pick( $row, $keys ) {
		foreach ( $keys as $key ) {
			if ( isset( $row[ $key ] ) && is_scalar( $row[ $key ] ) && '' !== trim( (string) $row[ $key ] ) ) {
				return trim( (string) $row[ $key ] );
			}
		}
		return '';
	}

	/**
	 * Maps a feed row (lowercase keys) to the fields the importer uses.
	 *
	 * @param array<string,mixed> $row Feed row.
	 * @return array<string,mixed>
	 */
	public static function normalize( $row ) {
		$url      = self::pick( $row, array( 'url', 'link', 'joburl', 'job_url' ) );
		$location = self::pick( $row, array( 'location', 'joblocation', 'job_location' ) );
		if ( '' === $location ) {
			$location = implode( ', ', array_filter( array( self::pick( $row, array( 'city' ) ), self::pick( $row, array( 'state', 'region' ) ), self::pick( $row, array( 'country' ) ) ) ) );
		}
		$arrangement = strtolower( self::pick( $row, array( 'workarrangement', 'remotetype', 'remote', 'work_arrangement' ) ) );
		$remote      = in_array( $arrangement, array( 'remote', 'fully remote', 'fully_remote', 'telecommute', 'true', '1', 'yes' ), true ) || 0 === strpos( $arrangement, 'remote' );
		$salary_min  = self::pick( $row, array( 'salarymin', 'salary_min', 'minsalary' ) );
		$salary_max  = self::pick( $row, array( 'salarymax', 'salary_max', 'maxsalary' ) );
		$posted      = self::pick( $row, array( 'postedat', 'date', 'pubdate', 'posted_at', 'dateposted', 'firstseenat' ) );
		$timestamp   = '' !== $posted ? strtotime( $posted ) : false;

		$job = array(
			'id'              => self::pick( $row, array( 'id', 'referencenumber', 'guid', 'jobid', 'job_id' ) ),
			'title'           => self::pick( $row, array( 'title', 'jobtitle', 'job_title' ) ),
			'company'         => self::pick( $row, array( 'company', 'companyname', 'company_name', 'sourcename', 'employer' ) ),
			'company_website' => self::pick( $row, array( 'companywebsite', 'company_website', 'companyurl' ) ),
			'logo'            => self::pick( $row, array( 'companylogo', 'logo', 'company_logo' ) ),
			'location'        => $location,
			'remote'          => $remote,
			'type'            => self::pick( $row, array( 'employmenttype', 'jobtype', 'job_type', 'type' ) ),
			'category'        => self::pick( $row, array( 'jobcategory', 'category', 'job_category' ) ),
			'salary_min'      => is_numeric( $salary_min ) ? $salary_min + 0 : '',
			'salary_max'      => is_numeric( $salary_max ) ? $salary_max + 0 : '',
			'salary_text'     => self::pick( $row, array( 'salary' ) ),
			'salary_currency' => strtoupper( self::pick( $row, array( 'salarycurrency', 'salary_currency', 'currency' ) ) ),
			'salary_period'   => strtolower( self::pick( $row, array( 'salaryperiod', 'salary_period' ) ) ),
			'posted'          => $timestamp ? (int) $timestamp : 0,
			'url'             => $url,
			'apply_url'       => self::pick( $row, array( 'applyurl', 'apply_url', 'applicationurl' ) ),
			'description'     => self::pick( $row, array( 'descriptionhtml', 'description', 'content', 'body' ) ),
		);
		if ( '' === $job['apply_url'] ) {
			$job['apply_url'] = $url;
		}
		if ( '' === $job['id'] ) {
			$job['id'] = '' !== $url ? $url : md5( $job['title'] . '|' . $job['company'] . '|' . $job['location'] );
		}
		return $job;
	}
}
