<?php
/**
 * Settings page under Job Listings.
 *
 * @package Deriverge_Job_Feed_Importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin screens and actions.
 */
class DJFI_Admin {

	const PAGE = 'djfi-feeds';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'admin_post_djfi_save_feed', array( __CLASS__, 'save_feed' ) );
		add_action( 'admin_post_djfi_delete_feed', array( __CLASS__, 'delete_feed' ) );
		add_action( 'admin_post_djfi_save_schedule', array( __CLASS__, 'save_schedule' ) );
		add_action( 'wp_ajax_djfi_step', array( __CLASS__, 'ajax_step' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DJFI_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Capability needed to manage feeds.
	 *
	 * @return string
	 */
	private static function cap() {
		return 'manage_options';
	}

	/**
	 * Address of the settings page.
	 *
	 * @param array<string,string> $args Extra query arguments.
	 * @return string
	 */
	public static function url( $args = array() ) {
		return add_query_arg(
			array_merge(
				array(
					'post_type' => 'job_listing',
					'page'      => self::PAGE,
				),
				$args
			),
			admin_url( 'edit.php' )
		);
	}

	/**
	 * Menu entry: under Job Listings when WP Job Manager is active, under Tools otherwise.
	 */
	public static function menu() {
		$parent = post_type_exists( 'job_listing' ) ? 'edit.php?post_type=job_listing' : 'tools.php';
		add_submenu_page( $parent, __( 'Job Feed Import', 'deriverge-job-feed-importer' ), __( 'Feed Import', 'deriverge-job-feed-importer' ), self::cap(), self::PAGE, array( __CLASS__, 'page' ) );
	}

	/**
	 * Settings link on the Plugins screen.
	 *
	 * @param string[] $links Links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">' . esc_html__( 'Feeds', 'deriverge-job-feed-importer' ) . '</a>' );
		return $links;
	}

	/**
	 * Script of the settings page.
	 *
	 * @param string $hook Current admin page.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}
		wp_enqueue_script( 'djfi-admin', plugins_url( 'assets/admin.js', DJFI_FILE ), array(), DJFI_VERSION, true );
		wp_localize_script(
			'djfi-admin',
			'djfiAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'djfi_step' ),
				'i18n'    => array(
					'starting' => __( 'Downloading the feed…', 'deriverge-job-feed-importer' ),
					/* translators: 1: jobs read, 2: new, 3: updated. */
					'progress' => __( '%1$s jobs read: %2$s new, %3$s updated…', 'deriverge-job-feed-importer' ),
					'closing'  => __( 'Closing jobs that left the feed…', 'deriverge-job-feed-importer' ),
					/* translators: 1: jobs read, 2: new, 3: updated, 4: unchanged, 5: closed. */
					'done'     => __( 'Done. %1$s jobs read: %2$s new, %3$s updated, %4$s unchanged, %5$s closed.', 'deriverge-job-feed-importer' ),
					'failed'   => __( 'The import stopped:', 'deriverge-job-feed-importer' ),
					'network'  => __( 'The request failed. Reload the page and run the import again; it continues where it stopped.', 'deriverge-job-feed-importer' ),
				),
			)
		);
	}

	/**
	 * Runs one batch for the settings page ("Run now").
	 */
	public static function ajax_step() {
		check_ajax_referer( 'djfi_step', 'nonce' );
		if ( ! current_user_can( self::cap() ) ) {
			wp_send_json_error( array( 'message' => __( 'You are not allowed to do this.', 'deriverge-job-feed-importer' ) ), 403 );
		}
		$feed_id = isset( $_POST['feed'] ) ? sanitize_key( wp_unslash( $_POST['feed'] ) ) : '';
		$feed    = djfi_get_feed( $feed_id );
		if ( ! $feed ) {
			wp_send_json_error( array( 'message' => __( 'This feed no longer exists.', 'deriverge-job-feed-importer' ) ), 404 );
		}
		if ( ! empty( $_POST['start'] ) ) {
			DJFI_Importer::start( $feed );
		}
		$state = DJFI_Importer::step( $feed_id );
		wp_send_json_success( $state );
	}

	/**
	 * Saves a new or edited feed.
	 */
	public static function save_feed() {
		if ( ! current_user_can( self::cap() ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'deriverge-job-feed-importer' ) );
		}
		check_admin_referer( 'djfi_save_feed' );
		$settings = djfi_get_settings();
		$feed_id  = isset( $_POST['feed_id'] ) ? sanitize_key( wp_unslash( $_POST['feed_id'] ) ) : '';
		if ( '' === $feed_id || ! isset( $settings['feeds'][ $feed_id ] ) ) {
			$feed_id = 'f' . substr( md5( uniqid( '', true ) ), 0, 8 );
		}
		$url     = isset( $_POST['url'] ) ? esc_url_raw( trim( sanitize_text_field( wp_unslash( $_POST['url'] ) ) ), array( 'http', 'https' ) ) : '';
		$status  = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'publish';
		$missing = isset( $_POST['missing'] ) ? sanitize_key( wp_unslash( $_POST['missing'] ) ) : 'expire';
		$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		if ( '' === $url ) {
			wp_safe_redirect( self::url( array( 'djfi_msg' => 'nourl' ) ) );
			exit;
		}
		$settings['feeds'][ $feed_id ] = array(
			'id'         => $feed_id,
			'name'       => '' !== $name ? $name : (string) wp_parse_url( $url, PHP_URL_HOST ),
			'url'        => $url,
			'enabled'    => empty( $_POST['enabled'] ) ? 0 : 1,
			'status'     => in_array( $status, array( 'publish', 'pending', 'draft' ), true ) ? $status : 'publish',
			'author'     => isset( $_POST['author'] ) ? absint( $_POST['author'] ) : get_current_user_id(),
			'missing'    => in_array( $missing, array( 'expire', 'filled', 'trash', 'keep' ), true ) ? $missing : 'expire',
			'categories' => empty( $_POST['categories'] ) ? 0 : 1,
			'types'      => empty( $_POST['types'] ) ? 0 : 1,
			'max_jobs'   => isset( $_POST['max_jobs'] ) ? absint( $_POST['max_jobs'] ) : 0,
		);
		update_option( 'djfi_settings', $settings, false );
		if ( ! wp_next_scheduled( 'djfi_cron' ) ) {
			djfi_reschedule( $settings['schedule'] );
		}
		wp_safe_redirect( self::url( array( 'djfi_msg' => 'saved' ) ) );
		exit;
	}

	/**
	 * Deletes a feed. Its listings stay.
	 */
	public static function delete_feed() {
		if ( ! current_user_can( self::cap() ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'deriverge-job-feed-importer' ) );
		}
		check_admin_referer( 'djfi_delete_feed' );
		$settings = djfi_get_settings();
		$feed_id  = isset( $_GET['feed'] ) ? sanitize_key( wp_unslash( $_GET['feed'] ) ) : '';
		unset( $settings['feeds'][ $feed_id ] );
		update_option( 'djfi_settings', $settings, false );
		delete_option( 'djfi_state_' . $feed_id );
		wp_safe_redirect( self::url( array( 'djfi_msg' => 'deleted' ) ) );
		exit;
	}

	/**
	 * Saves how often the feeds are imported.
	 */
	public static function save_schedule() {
		if ( ! current_user_can( self::cap() ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'deriverge-job-feed-importer' ) );
		}
		check_admin_referer( 'djfi_save_schedule' );
		$settings = djfi_get_settings();
		$schedule = isset( $_POST['schedule'] ) ? sanitize_key( wp_unslash( $_POST['schedule'] ) ) : 'daily';
		if ( ! in_array( $schedule, array( 'hourly', 'twicedaily', 'daily', 'manual' ), true ) ) {
			$schedule = 'daily';
		}
		$settings['schedule'] = $schedule;
		update_option( 'djfi_settings', $settings, false );
		djfi_reschedule( $schedule );
		wp_safe_redirect( self::url( array( 'djfi_msg' => 'saved' ) ) );
		exit;
	}

	/**
	 * One-line summary of a feed's last run.
	 *
	 * @param array<string,mixed>|null $state State.
	 * @return string
	 */
	private static function summary( $state ) {
		if ( ! $state ) {
			return __( 'Not imported yet.', 'deriverge-job-feed-importer' );
		}
		if ( 'error' === $state['phase'] ) {
			return $state['error'];
		}
		if ( 'done' !== $state['phase'] ) {
			/* translators: %s: number of jobs. */
			return sprintf( __( 'Import in progress: %s jobs read so far.', 'deriverge-job-feed-importer' ), number_format_i18n( $state['read'] ) );
		}
		return sprintf(
			/* translators: 1: date and time, 2: jobs read, 3: new, 4: updated, 5: closed. */
			__( '%1$s: %2$s jobs read, %3$s new, %4$s updated, %5$s closed.', 'deriverge-job-feed-importer' ),
			wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $state['finished'] ),
			number_format_i18n( $state['read'] ),
			number_format_i18n( $state['created'] ),
			number_format_i18n( $state['updated'] ),
			number_format_i18n( $state['closed'] )
		);
	}

	/**
	 * The settings page.
	 */
	public static function page() {
		if ( ! current_user_can( self::cap() ) ) {
			return;
		}
		$settings = djfi_get_settings();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only view parameters.
		$edit_id = isset( $_GET['feed'] ) ? sanitize_key( wp_unslash( $_GET['feed'] ) ) : '';
		$msg     = isset( $_GET['djfi_msg'] ) ? sanitize_key( wp_unslash( $_GET['djfi_msg'] ) ) : '';
		$adding  = isset( $_GET['add'] );
		// phpcs:enable
		$editing = $edit_id ? djfi_get_feed( $edit_id ) : null;
		$next    = wp_next_scheduled( 'djfi_cron' );

		echo '<div class="wrap"><h1 class="wp-heading-inline">' . esc_html__( 'Job Feed Import', 'deriverge-job-feed-importer' ) . '</h1> ';
		echo '<a class="page-title-action" href="' . esc_url( self::url( array( 'add' => '1' ) ) ) . '">' . esc_html__( 'Add feed', 'deriverge-job-feed-importer' ) . '</a><hr class="wp-header-end">';

		if ( ! post_type_exists( 'job_listing' ) ) {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'WP Job Manager is not active. Install and activate it first; the imported jobs become its job listings.', 'deriverge-job-feed-importer' ) . '</p></div>';
		}
		$messages = array(
			'saved'   => __( 'Saved.', 'deriverge-job-feed-importer' ),
			'deleted' => __( 'Feed deleted. The jobs it imported stay on the site.', 'deriverge-job-feed-importer' ),
			'nourl'   => __( 'Enter the address of a feed.', 'deriverge-job-feed-importer' ),
		);
		if ( isset( $messages[ $msg ] ) ) {
			echo '<div class="notice ' . ( 'nourl' === $msg ? 'notice-error' : 'notice-success' ) . ' is-dismissible"><p>' . esc_html( $messages[ $msg ] ) . '</p></div>';
		}

		if ( $editing || $adding || empty( $settings['feeds'] ) ) {
			self::form( $editing );
		}

		if ( ! empty( $settings['feeds'] ) ) {
			echo '<h2>' . esc_html__( 'Feeds', 'deriverge-job-feed-importer' ) . '</h2>';
			echo '<table class="widefat striped"><thead><tr><th>' . esc_html__( 'Feed', 'deriverge-job-feed-importer' ) . '</th><th>' . esc_html__( 'Last import', 'deriverge-job-feed-importer' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( array_keys( $settings['feeds'] ) as $feed_id ) {
				$feed = djfi_get_feed( (string) $feed_id );
				if ( ! $feed ) {
					continue;
				}
				$state = DJFI_Importer::get_state( $feed['id'] );
				echo '<tr><td><strong>' . esc_html( $feed['name'] ) . '</strong>' . ( empty( $feed['enabled'] ) ? ' <em>(' . esc_html__( 'paused', 'deriverge-job-feed-importer' ) . ')</em>' : '' ) . '<br><code style="word-break:break-all">' . esc_html( $feed['url'] ) . '</code></td>';
				echo '<td><span class="djfi-status" data-feed="' . esc_attr( $feed['id'] ) . '">' . esc_html( self::summary( $state ) ) . '</span></td>';
				echo '<td style="white-space:nowrap"><button type="button" class="button button-primary djfi-run" data-feed="' . esc_attr( $feed['id'] ) . '">' . esc_html__( 'Run now', 'deriverge-job-feed-importer' ) . '</button> ';
				echo '<a class="button" href="' . esc_url( self::url( array( 'feed' => $feed['id'] ) ) ) . '">' . esc_html__( 'Edit', 'deriverge-job-feed-importer' ) . '</a> ';
				echo '<a class="button-link-delete" style="margin-left:8px" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=djfi_delete_feed&feed=' . $feed['id'] ), 'djfi_delete_feed' ) ) . '">' . esc_html__( 'Delete', 'deriverge-job-feed-importer' ) . '</a></td></tr>';
			}
			echo '</tbody></table>';

			echo '<h2>' . esc_html__( 'Schedule', 'deriverge-job-feed-importer' ) . '</h2>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="djfi_save_schedule">';
			wp_nonce_field( 'djfi_save_schedule' );
			echo '<p><label for="djfi-schedule">' . esc_html__( 'Import every feed', 'deriverge-job-feed-importer' ) . '</label> <select id="djfi-schedule" name="schedule">';
			$options = array(
				'daily'      => __( 'once a day', 'deriverge-job-feed-importer' ),
				'twicedaily' => __( 'twice a day', 'deriverge-job-feed-importer' ),
				'hourly'     => __( 'every hour', 'deriverge-job-feed-importer' ),
				'manual'     => __( 'only when I press Run now', 'deriverge-job-feed-importer' ),
			);
			foreach ( $options as $value => $label ) {
				echo '<option value="' . esc_attr( $value ) . '"' . selected( $settings['schedule'], $value, false ) . '>' . esc_html( $label ) . '</option>';
			}
			echo '</select> ';
			submit_button( __( 'Save', 'deriverge-job-feed-importer' ), 'secondary', 'submit', false );
			echo '</p><p class="description">';
			if ( $next ) {
				/* translators: %s: date and time. */
				echo esc_html( sprintf( __( 'Next scheduled import: %s.', 'deriverge-job-feed-importer' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $next ) ) ) . ' ';
			}
			echo esc_html__( 'Scheduled imports use WP-Cron, which runs when the site has visitors. Most job feeds change once a day.', 'deriverge-job-feed-importer' ) . '</p></form>';
		}

		$log = get_option( 'djfi_log', array() );
		if ( is_array( $log ) && $log ) {
			echo '<h2>' . esc_html__( 'Recent imports', 'deriverge-job-feed-importer' ) . '</h2><table class="widefat striped"><thead><tr>';
			foreach ( array( __( 'Finished', 'deriverge-job-feed-importer' ), __( 'Feed', 'deriverge-job-feed-importer' ), __( 'Read', 'deriverge-job-feed-importer' ), __( 'New', 'deriverge-job-feed-importer' ), __( 'Updated', 'deriverge-job-feed-importer' ), __( 'Closed', 'deriverge-job-feed-importer' ), __( 'Skipped', 'deriverge-job-feed-importer' ) ) as $head ) {
				echo '<th>' . esc_html( $head ) . '</th>';
			}
			echo '</tr></thead><tbody>';
			foreach ( array_slice( $log, 0, 10 ) as $row ) {
				echo '<tr><td>' . esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $row['time'] ) ) . '</td><td>' . esc_html( $row['name'] ) . '</td>';
				foreach ( array( 'read', 'created', 'updated', 'closed', 'skipped' ) as $key ) {
					echo '<td>' . esc_html( number_format_i18n( (int) $row[ $key ] ) ) . '</td>';
				}
				echo '</tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}

	/**
	 * Add or edit form.
	 *
	 * @param array<string,mixed>|null $feed Feed being edited, or null for a new one.
	 */
	private static function form( $feed ) {
		$is_new = ! $feed;
		$feed   = $feed ? $feed : array(
			'id'         => '',
			'name'       => '',
			'url'        => '',
			'enabled'    => 1,
			'status'     => 'publish',
			'author'     => get_current_user_id(),
			'missing'    => 'expire',
			'categories' => 1,
			'types'      => 1,
			'max_jobs'   => 0,
		);
		$sample = 'https://deriverge.com/tools/data/job-feed-sample.xml';

		echo '<h2>' . esc_html( $is_new ? __( 'Add a feed', 'deriverge-job-feed-importer' ) : __( 'Edit feed', 'deriverge-job-feed-importer' ) ) . '</h2>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="djfi_save_feed"><input type="hidden" name="feed_id" value="' . esc_attr( $feed['id'] ) . '">';
		wp_nonce_field( 'djfi_save_feed' );
		echo '<table class="form-table" role="presentation"><tbody>';

		echo '<tr><th scope="row"><label for="djfi-url">' . esc_html__( 'Feed address', 'deriverge-job-feed-importer' ) . '</label></th><td><input type="url" class="large-text code" id="djfi-url" name="url" required value="' . esc_attr( $feed['url'] ) . '" placeholder="https://">';
		echo '<p class="description">' . esc_html__( 'The address of an XML, JSON or JSON Lines job feed. Gzip-compressed feeds work too.', 'deriverge-job-feed-importer' ) . '</p>';
		if ( $is_new ) {
			echo '<p class="description">' . esc_html__( 'No feed yet?', 'deriverge-job-feed-importer' ) . ' <button type="button" class="button-link" id="djfi-sample" data-url="' . esc_attr( $sample ) . '">' . esc_html__( 'Fill in a free sample feed', 'deriverge-job-feed-importer' ) . '</button> ';
			echo wp_kses(
				sprintf(
					/* translators: %s: link to deriverge.com. */
					__( 'or get a daily feed of jobs for your country or niche from %s (a paid service).', 'deriverge-job-feed-importer' ),
					'<a href="https://deriverge.com/tools/job-data-feed/" target="_blank" rel="noopener noreferrer">deriverge</a>'
				),
				array(
					'a' => array(
						'href'   => array(),
						'target' => array(),
						'rel'    => array(),
					),
				)
			) . '</p>';
		}
		echo '</td></tr>';

		echo '<tr><th scope="row"><label for="djfi-name">' . esc_html__( 'Name', 'deriverge-job-feed-importer' ) . '</label></th><td><input type="text" class="regular-text" id="djfi-name" name="name" value="' . esc_attr( $feed['name'] ) . '"><p class="description">' . esc_html__( 'Only for you, to tell feeds apart.', 'deriverge-job-feed-importer' ) . '</p></td></tr>';

		echo '<tr><th scope="row"><label for="djfi-status">' . esc_html__( 'New jobs are', 'deriverge-job-feed-importer' ) . '</label></th><td><select id="djfi-status" name="status">';
		$statuses = array(
			'publish' => __( 'published right away', 'deriverge-job-feed-importer' ),
			'pending' => __( 'saved as pending, for my approval', 'deriverge-job-feed-importer' ),
			'draft'   => __( 'saved as drafts', 'deriverge-job-feed-importer' ),
		);
		foreach ( $statuses as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $feed['status'], $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></td></tr>';

		echo '<tr><th scope="row"><label for="djfi-missing">' . esc_html__( 'When a job leaves the feed', 'deriverge-job-feed-importer' ) . '</label></th><td><select id="djfi-missing" name="missing">';
		$missing = array(
			'expire' => __( 'mark it as expired', 'deriverge-job-feed-importer' ),
			'filled' => __( 'mark it as filled', 'deriverge-job-feed-importer' ),
			'trash'  => __( 'move it to the trash', 'deriverge-job-feed-importer' ),
			'keep'   => __( 'leave it as it is', 'deriverge-job-feed-importer' ),
		);
		foreach ( $missing as $value => $label ) {
			echo '<option value="' . esc_attr( $value ) . '"' . selected( $feed['missing'], $value, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select><p class="description">' . esc_html__( 'A feed of open jobs drops a job when the employer closes it. An empty or unreachable feed never closes anything.', 'deriverge-job-feed-importer' ) . '</p></td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Job types and categories', 'deriverge-job-feed-importer' ) . '</th><td><label><input type="checkbox" name="types" value="1"' . checked( ! empty( $feed['types'] ), true, false ) . '> ' . esc_html__( 'Set the job type (full time, part time, freelance, temporary, internship) when the feed gives one', 'deriverge-job-feed-importer' ) . '</label><br>';
		echo '<label><input type="checkbox" name="categories" value="1"' . checked( ! empty( $feed['categories'] ), true, false ) . '> ' . esc_html__( 'Set the job category from the feed and create categories that do not exist yet', 'deriverge-job-feed-importer' ) . '</label>';
		echo '<p class="description">' . esc_html__( 'Categories apply when they are enabled in the WP Job Manager settings.', 'deriverge-job-feed-importer' ) . '</p></td></tr>';

		echo '<tr><th scope="row"><label for="djfi-max">' . esc_html__( 'Most jobs to import', 'deriverge-job-feed-importer' ) . '</label></th><td><input type="number" min="0" step="1" class="small-text" id="djfi-max" name="max_jobs" value="' . esc_attr( (string) (int) $feed['max_jobs'] ) . '"> <span class="description">' . esc_html__( '0 imports the whole feed.', 'deriverge-job-feed-importer' ) . '</span></td></tr>';

		echo '<tr><th scope="row"><label for="djfi-author">' . esc_html__( 'Author of the jobs', 'deriverge-job-feed-importer' ) . '</label></th><td>';
		wp_dropdown_users(
			array(
				'name'       => 'author',
				'id'         => 'djfi-author',
				'selected'   => (int) $feed['author'] ? (int) $feed['author'] : get_current_user_id(),
				'capability' => array( 'edit_posts' ),
			)
		);
		echo '</td></tr>';

		echo '<tr><th scope="row">' . esc_html__( 'Scheduled import', 'deriverge-job-feed-importer' ) . '</th><td><label><input type="checkbox" name="enabled" value="1"' . checked( ! empty( $feed['enabled'] ), true, false ) . '> ' . esc_html__( 'Import this feed on the schedule', 'deriverge-job-feed-importer' ) . '</label></td></tr>';

		echo '</tbody></table>';
		submit_button( $is_new ? __( 'Add feed', 'deriverge-job-feed-importer' ) : __( 'Save feed', 'deriverge-job-feed-importer' ) );
		echo '</form>';
	}
}
