<?php
/**
 * Imports feed jobs as WP Job Manager listings, in short batches that survive request time limits.
 *
 * @package Deriverge_Job_Feed_Importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Importer.
 */
class DJFI_Importer {

	/**
	 * State of a feed's current or last run.
	 *
	 * @param string $feed_id Feed id.
	 * @return array<string,mixed>|null
	 */
	public static function get_state( $feed_id ) {
		$state = get_option( 'djfi_state_' . $feed_id );
		return is_array( $state ) ? $state : null;
	}

	/**
	 * Saves the state.
	 *
	 * @param string              $feed_id Feed id.
	 * @param array<string,mixed> $state   State.
	 */
	private static function save_state( $feed_id, $state ) {
		update_option( 'djfi_state_' . $feed_id, $state, false );
	}

	/**
	 * Ends a run with an error.
	 *
	 * @param string              $feed_id Feed id.
	 * @param array<string,mixed> $state   State.
	 * @param string              $message Message for the admin.
	 * @return array<string,mixed>
	 */
	private static function fail( $feed_id, $state, $message ) {
		$state['phase']    = 'error';
		$state['error']    = $message;
		$state['finished'] = time();
		self::cleanup_file( $state );
		self::save_state( $feed_id, $state );
		return $state;
	}

	/**
	 * Deletes the downloaded feed file.
	 *
	 * @param array<string,mixed> $state State.
	 */
	private static function cleanup_file( $state ) {
		if ( ! empty( $state['file'] ) && file_exists( $state['file'] ) ) {
			wp_delete_file( $state['file'] );
		}
	}

	/**
	 * Starts a new run of a feed. The work itself happens in step().
	 *
	 * @param array<string,mixed> $feed Feed settings.
	 * @return array<string,mixed>
	 */
	public static function start( $feed ) {
		$old = self::get_state( $feed['id'] );
		if ( $old && ! in_array( $old['phase'], array( 'done', 'error' ), true ) && ( time() - (int) $old['touched'] ) < 15 * MINUTE_IN_SECONDS ) {
			return $old; // A run is in progress.
		}
		if ( $old ) {
			self::cleanup_file( $old );
		}
		$state = array(
			'run'      => (string) time(),
			'phase'    => 'download',
			'file'     => '',
			'format'   => '',
			'offset'   => 0,
			'read'     => 0,
			'created'  => 0,
			'updated'  => 0,
			'same'     => 0,
			'skipped'  => 0,
			'closed'   => 0,
			'started'  => time(),
			'touched'  => time(),
			'finished' => 0,
			'error'    => '',
		);
		self::save_state( $feed['id'], $state );
		return $state;
	}

	/**
	 * Downloads the feed to a temp file and detects its format.
	 *
	 * @param array<string,mixed> $feed  Feed settings.
	 * @param array<string,mixed> $state State.
	 * @return array<string,mixed>
	 */
	private static function download( $feed, $state ) {
		$url = (string) $feed['url'];
		// A feed page of the deriverge job data feed: the files sit next to it.
		$url = preg_replace( '#/records/(index\.html|manifest\.json)(\?.*)?$#', '/records/open.jsonl', $url );
		require_once ABSPATH . 'wp-admin/includes/file.php'; // wp_tempnam() is not loaded during WP-Cron.
		$tmp = wp_tempnam( 'djfi-feed' );
		/**
		 * Largest feed file the importer downloads, in bytes.
		 *
		 * @param int $bytes Default 300 MB.
		 */
		$max      = (int) apply_filters( 'djfi_max_feed_bytes', 300 * MB_IN_BYTES );
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => 120,
				'stream'              => true,
				'filename'            => $tmp,
				'limit_response_size' => $max,
				'user-agent'          => 'deriverge-job-feed-importer/' . DJFI_VERSION . '; ' . home_url( '/' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			wp_delete_file( $tmp );
			/* translators: %s: error message. */
			return self::fail( $feed['id'], $state, sprintf( __( 'The feed could not be downloaded: %s', 'deriverge-job-feed-importer' ), $response->get_error_message() ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			wp_delete_file( $tmp );
			/* translators: %d: HTTP status code. */
			return self::fail( $feed['id'], $state, sprintf( __( 'The feed address answered with HTTP %d.', 'deriverge-job-feed-importer' ), $code ) );
		}
		$format = DJFI_Reader::detect( $tmp );
		if ( 'gzip' === $format ) {
			$unpacked = DJFI_Reader::gunzip( $tmp );
			wp_delete_file( $tmp );
			if ( is_wp_error( $unpacked ) ) {
				return self::fail( $feed['id'], $state, $unpacked->get_error_message() );
			}
			$tmp    = $unpacked;
			$format = DJFI_Reader::detect( $tmp );
		}
		if ( 'html' === $format ) {
			wp_delete_file( $tmp );
			return self::fail( $feed['id'], $state, __( 'The address returned a web page, not a feed. Use the address of the XML, JSON or JSON Lines file.', 'deriverge-job-feed-importer' ) );
		}
		if ( 'unknown' === $format ) {
			wp_delete_file( $tmp );
			return self::fail( $feed['id'], $state, __( 'The address did not return an XML, JSON or JSON Lines job feed.', 'deriverge-job-feed-importer' ) );
		}
		$state['file']    = $tmp;
		$state['format']  = $format;
		$state['phase']   = 'import';
		$state['touched'] = time();
		return $state;
	}

	/**
	 * Runs one short batch of a feed's run and returns the new state.
	 *
	 * @param string $feed_id Feed id.
	 * @return array<string,mixed>|null
	 */
	public static function step( $feed_id ) {
		$feed  = djfi_get_feed( $feed_id );
		$state = self::get_state( $feed_id );
		if ( ! $feed || ! $state || in_array( $state['phase'], array( 'done', 'error' ), true ) ) {
			return $state;
		}
		if ( ! post_type_exists( 'job_listing' ) ) {
			return self::fail( $feed_id, $state, __( 'WP Job Manager is not active.', 'deriverge-job-feed-importer' ) );
		}
		$lock = 'djfi_lock_' . $feed_id;
		if ( get_transient( $lock ) ) {
			return $state; // Another request is working on this feed right now.
		}
		set_transient( $lock, 1, 2 * MINUTE_IN_SECONDS );

		/**
		 * Seconds one batch may run, and jobs one batch may write.
		 *
		 * @param int $value Default 15 seconds and 60 jobs.
		 */
		$deadline = microtime( true ) + (int) apply_filters( 'djfi_batch_seconds', 15 );
		$budget   = (int) apply_filters( 'djfi_batch_jobs', 60 );

		if ( 'download' === $state['phase'] || ( 'import' === $state['phase'] && ! file_exists( $state['file'] ) ) ) {
			$state = self::download( $feed, $state );
			if ( 'error' === $state['phase'] ) {
				delete_transient( $lock );
				return $state;
			}
			self::save_state( $feed_id, $state );
		}

		wp_defer_term_counting( true );

		if ( 'import' === $state['phase'] ) {
			$max = (int) $feed['max_jobs'];
			while ( $budget > 0 && microtime( true ) < $deadline ) {
				$take  = min( 10, $budget, $max > 0 ? max( 0, $max - (int) $state['read'] ) : 10 );
				$slice = $take > 0 ? DJFI_Reader::read( $state['file'], $state['format'], (int) $state['offset'], $take ) : array(
					'jobs' => array(),
					'next' => (int) $state['offset'],
					'done' => true,
				);
				if ( is_wp_error( $slice ) ) {
					wp_defer_term_counting( false );
					delete_transient( $lock );
					return self::fail( $feed_id, $state, $slice->get_error_message() );
				}
				foreach ( $slice['jobs'] as $job ) {
					$result = self::upsert( $feed, $job, $state['run'] );
					++$state[ $result ];
					++$state['read'];
					--$budget;
				}
				$state['offset'] = $slice['next'];
				if ( $slice['done'] || ( $max > 0 && (int) $state['read'] >= $max ) ) {
					$state['phase'] = 'cleanup';
					self::cleanup_file( $state );
					$state['file'] = '';
					break;
				}
			}
		}

		if ( 'cleanup' === $state['phase'] && microtime( true ) < $deadline ) {
			$written = (int) $state['created'] + (int) $state['updated'] + (int) $state['same'];
			if ( 'keep' === $feed['missing'] || 0 === $written ) {
				// An empty or unreadable feed must never close every job on the site.
				$state['phase'] = 'done';
			} else {
				$closed = self::close_missing( $feed, $state['run'], 100 );
				$state['closed'] += $closed;
				if ( $closed < 100 ) {
					$state['phase'] = 'done';
				}
			}
			if ( 'done' === $state['phase'] ) {
				$state['finished'] = time();
				self::log( $feed, $state );
			}
		}

		wp_defer_term_counting( false );
		$state['touched'] = time();
		self::save_state( $feed_id, $state );
		delete_transient( $lock );
		return $state;
	}

	/**
	 * Creates or updates one listing. Returns the counter to increase: created, updated, same or skipped.
	 *
	 * @param array<string,mixed> $feed Feed settings.
	 * @param array<string,mixed> $job  Normalized job.
	 * @param string              $run  Run id.
	 * @return string
	 */
	private static function upsert( $feed, $job, $run ) {
		if ( '' === $job['title'] ) {
			return 'skipped';
		}
		/**
		 * Filters a feed job before it is written. Return false to skip the job.
		 *
		 * @param array<string,mixed>|false $job  Normalized job.
		 * @param array<string,mixed>       $feed Feed settings.
		 */
		$job = apply_filters( 'djfi_job', $job, $feed );
		if ( ! is_array( $job ) ) {
			return 'skipped';
		}

		$key      = md5( $feed['id'] . '|' . $job['id'] );
		$hash     = md5( (string) wp_json_encode( $job ) . '|' . $feed['status'] . '|' . $feed['categories'] . '|' . $feed['types'] );
		$existing = get_posts(
			array(
				'post_type'        => 'job_listing',
				'post_status'      => array( 'publish', 'pending', 'draft', 'expired', 'private', 'trash', 'preview' ),
				'meta_key'         => '_djfi_key', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- the lookup that prevents duplicates.
				'meta_value'       => $key, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'fields'           => 'ids',
				'numberposts'      => 1,
				'suppress_filters' => true,
			)
		);
		$post_id  = $existing ? (int) $existing[0] : 0;

		if ( $post_id ) {
			update_post_meta( $post_id, '_djfi_run', $run );
			$status = get_post_status( $post_id );
			if ( 'trash' === $status ) {
				return 'skipped'; // The site owner removed this job; do not bring it back.
			}
			$closed_by_us = '1' === (string) get_post_meta( $post_id, '_djfi_closed', true );
			if ( get_post_meta( $post_id, '_djfi_hash', true ) === $hash && ! $closed_by_us ) {
				return 'same';
			}
		}

		$content = wp_kses_post( $job['description'] );
		$postarr = array(
			'post_type'    => 'job_listing',
			'post_title'   => sanitize_text_field( $job['title'] ),
			'post_content' => $content,
		);
		if ( $post_id ) {
			$postarr['ID'] = $post_id;
			if ( ! empty( $closed_by_us ) ) {
				$postarr['post_status'] = $feed['status']; // Back in the feed: reopen.
			}
			$result = wp_update_post( wp_slash( $postarr ), true );
		} else {
			$postarr['post_status'] = $feed['status'];
			$postarr['post_author'] = (int) $feed['author'];
			if ( $job['posted'] && $job['posted'] <= time() ) {
				$postarr['post_date_gmt'] = gmdate( 'Y-m-d H:i:s', $job['posted'] );
				$postarr['post_date']     = get_date_from_gmt( $postarr['post_date_gmt'] );
			}
			$result = wp_insert_post( wp_slash( $postarr ), true );
		}
		if ( is_wp_error( $result ) || ! $result ) {
			return 'skipped';
		}
		$created = ! $post_id;
		$post_id = (int) $result;

		$meta = array(
			'_djfi_key'        => $key,
			'_djfi_feed'       => $feed['id'],
			'_djfi_run'        => $run,
			'_djfi_hash'       => $hash,
			'_djfi_source_url' => esc_url_raw( $job['url'] ),
			'_job_location'    => sanitize_text_field( $job['location'] ),
			'_application'     => esc_url_raw( $job['apply_url'] ),
			'_company_name'    => sanitize_text_field( $job['company'] ),
			'_company_website' => esc_url_raw( $job['company_website'] ),
			'_remote_position' => $job['remote'] ? 1 : 0,
			'_filled'          => 0,
		);
		if ( $created ) {
			$meta['_featured'] = 0;
		}
		$salary = self::salary( $job );
		foreach ( $salary as $meta_key => $value ) {
			$meta[ $meta_key ] = $value;
		}
		foreach ( $meta as $meta_key => $value ) {
			update_post_meta( $post_id, $meta_key, $value );
		}
		// The job stays open for as long as it is in the feed; the feed, not a fixed duration, closes it.
		delete_post_meta( $post_id, '_job_expires' );
		delete_post_meta( $post_id, '_djfi_closed' );

		if ( ! empty( $feed['types'] ) && taxonomy_exists( 'job_listing_type' ) ) {
			$type = self::job_type( $job['type'] );
			if ( '' !== $type && term_exists( $type, 'job_listing_type' ) ) {
				wp_set_object_terms( $post_id, $type, 'job_listing_type' );
			}
		}
		if ( ! empty( $feed['categories'] ) && taxonomy_exists( 'job_listing_category' ) && '' !== $job['category'] ) {
			$slug = sanitize_title( $job['category'] );
			$term = term_exists( $slug, 'job_listing_category' );
			if ( ! $term ) {
				$name = ucwords( str_replace( array( '-', '_' ), ' ', $job['category'] ) );
				$name = preg_replace( array( '/\bHr\b/', '/\bIt\b/' ), array( 'HR', 'IT' ), $name );
				$term = wp_insert_term( $name, 'job_listing_category', array( 'slug' => $slug ) );
			}
			if ( ! is_wp_error( $term ) && $term ) {
				wp_set_object_terms( $post_id, (int) $term['term_id'], 'job_listing_category' );
			}
		}

		/**
		 * Fires after a feed job was written as a listing.
		 *
		 * @param int                 $post_id Listing id.
		 * @param array<string,mixed> $job     Normalized job.
		 * @param array<string,mixed> $feed    Feed settings.
		 * @param bool                $created True for a new listing.
		 */
		do_action( 'djfi_job_saved', $post_id, $job, $feed, $created );

		return $created ? 'created' : 'updated';
	}

	/**
	 * Salary meta in the form WP Job Manager's salary fields use.
	 *
	 * @param array<string,mixed> $job Normalized job.
	 * @return array<string,string>
	 */
	private static function salary( $job ) {
		$min = $job['salary_min'];
		$max = $job['salary_max'];
		if ( '' === $min && '' === $max ) {
			$text = sanitize_text_field( $job['salary_text'] );
			return '' === $text ? array() : array( '_job_salary' => $text );
		}
		if ( '' !== $min && '' !== $max && $min != $max ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseNotEqual -- int against float.
			$amount = $min . '-' . $max;
		} else {
			$amount = (string) ( '' !== $min ? $min : $max );
		}
		$units = array(
			'year'  => 'YEAR',
			'month' => 'MONTH',
			'week'  => 'WEEK',
			'day'   => 'DAY',
			'hour'  => 'HOUR',
		);
		$out   = array( '_job_salary' => $amount );
		if ( '' !== $job['salary_currency'] ) {
			$out['_job_salary_currency'] = sanitize_text_field( $job['salary_currency'] );
		}
		if ( isset( $units[ $job['salary_period'] ] ) ) {
			$out['_job_salary_unit'] = $units[ $job['salary_period'] ];
		}
		return $out;
	}

	/**
	 * Maps the many spellings of employment types to WP Job Manager's default job type slugs.
	 *
	 * @param string $raw Employment type from the feed.
	 * @return string Slug, or an empty string.
	 */
	public static function job_type( $raw ) {
		$t = preg_replace( '/[^a-z]/', '', strtolower( (string) $raw ) );
		if ( '' === $t ) {
			return '';
		}
		if ( false !== strpos( $t, 'intern' ) || false !== strpos( $t, 'trainee' ) ) {
			return 'internship';
		}
		if ( false !== strpos( $t, 'parttime' ) ) {
			return 'part-time';
		}
		if ( false !== strpos( $t, 'contract' ) || false !== strpos( $t, 'freelance' ) ) {
			return 'freelance';
		}
		if ( false !== strpos( $t, 'temp' ) || false !== strpos( $t, 'fixedterm' ) || false !== strpos( $t, 'seasonal' ) ) {
			return 'temporary';
		}
		if ( false !== strpos( $t, 'fulltime' ) || false !== strpos( $t, 'permanent' ) || 'regular' === $t ) {
			return 'full-time';
		}
		return '';
	}

	/**
	 * Closes listings of this feed that the current run did not see. Returns how many were handled.
	 *
	 * @param array<string,mixed> $feed  Feed settings.
	 * @param string              $run   Run id.
	 * @param int                 $limit Batch size.
	 * @return int
	 */
	private static function close_missing( $feed, $run, $limit ) {
		$ids = get_posts(
			array(
				'post_type'        => 'job_listing',
				'post_status'      => array( 'publish', 'pending', 'draft' ),
				'fields'           => 'ids',
				'numberposts'      => $limit,
				'suppress_filters' => true,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- runs once per import, in batches.
				'meta_query'       => array(
					'relation' => 'AND',
					array(
						'key'   => '_djfi_feed',
						'value' => $feed['id'],
					),
					array(
						'key'     => '_djfi_run',
						'value'   => $run,
						'compare' => '!=',
					),
				),
			)
		);
		foreach ( $ids as $post_id ) {
			update_post_meta( $post_id, '_djfi_run', $run );
			update_post_meta( $post_id, '_djfi_closed', 1 );
			if ( 'trash' === $feed['missing'] ) {
				wp_trash_post( $post_id );
			} elseif ( 'filled' === $feed['missing'] ) {
				update_post_meta( $post_id, '_filled', 1 );
			} else {
				wp_update_post(
					array(
						'ID'          => $post_id,
						'post_status' => 'expired',
					)
				);
			}
		}
		return count( $ids );
	}

	/**
	 * Keeps the last 30 run summaries.
	 *
	 * @param array<string,mixed> $feed  Feed settings.
	 * @param array<string,mixed> $state Final state.
	 */
	private static function log( $feed, $state ) {
		$log = get_option( 'djfi_log', array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}
		array_unshift(
			$log,
			array(
				'feed'    => $feed['id'],
				'name'    => $feed['name'],
				'time'    => $state['finished'],
				'seconds' => $state['finished'] - $state['started'],
				'read'    => $state['read'],
				'created' => $state['created'],
				'updated' => $state['updated'],
				'closed'  => $state['closed'],
				'skipped' => $state['skipped'],
			)
		);
		update_option( 'djfi_log', array_slice( $log, 0, 30 ), false );
	}
}
