<?php
/**
 * Plugin Name:       Deriverge Job Feed Importer for WP Job Manager
 * Plugin URI:        https://deriverge.com/tools/job-data-feed/wp-job-manager/
 * Description:       Imports jobs from an XML, JSON or JSON Lines job feed into WP Job Manager on a schedule, updates the jobs that changed and expires the ones that left the feed.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Requires Plugins:  wp-job-manager
 * Author:            deriverge
 * Author URI:        https://deriverge.com/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       deriverge-job-feed-importer
 *
 * @package Deriverge_Job_Feed_Importer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DJFI_VERSION', '1.0.0' );
define( 'DJFI_FILE', __FILE__ );
define( 'DJFI_DIR', plugin_dir_path( __FILE__ ) );

require_once DJFI_DIR . 'includes/class-djfi-reader.php';
require_once DJFI_DIR . 'includes/class-djfi-importer.php';
require_once DJFI_DIR . 'includes/class-djfi-admin.php';

/**
 * Plugin settings with defaults filled in.
 *
 * @return array{schedule:string,feeds:array<string,array<string,mixed>>}
 */
function djfi_get_settings() {
	$settings = get_option( 'djfi_settings', array() );
	if ( ! is_array( $settings ) ) {
		$settings = array();
	}
	$settings = wp_parse_args(
		$settings,
		array(
			'schedule' => 'daily',
			'feeds'    => array(),
		)
	);
	if ( ! is_array( $settings['feeds'] ) ) {
		$settings['feeds'] = array();
	}
	return $settings;
}

/**
 * One feed's settings, or null when it does not exist.
 *
 * @param string $feed_id Feed id.
 * @return array<string,mixed>|null
 */
function djfi_get_feed( $feed_id ) {
	$settings = djfi_get_settings();
	if ( empty( $settings['feeds'][ $feed_id ] ) ) {
		return null;
	}
	return wp_parse_args(
		$settings['feeds'][ $feed_id ],
		array(
			'id'         => $feed_id,
			'name'       => '',
			'url'        => '',
			'enabled'    => 1,
			'status'     => 'publish',
			'author'     => 0,
			'missing'    => 'expire',
			'categories' => 1,
			'types'      => 1,
			'max_jobs'   => 0,
		)
	);
}

/**
 * (Re)schedules the recurring import.
 *
 * @param string $recurrence hourly, twicedaily or daily.
 */
function djfi_reschedule( $recurrence ) {
	wp_clear_scheduled_hook( 'djfi_cron' );
	if ( in_array( $recurrence, array( 'hourly', 'twicedaily', 'daily' ), true ) ) {
		wp_schedule_event( time() + 5 * MINUTE_IN_SECONDS, $recurrence, 'djfi_cron' );
	}
}

register_activation_hook(
	__FILE__,
	static function () {
		$settings = djfi_get_settings();
		djfi_reschedule( $settings['schedule'] );
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		wp_clear_scheduled_hook( 'djfi_cron' );
		wp_clear_scheduled_hook( 'djfi_continue' );
	}
);

// Scheduled run: start every enabled feed, the rest of each import continues in its own events.
add_action(
	'djfi_cron',
	static function () {
		$settings = djfi_get_settings();
		foreach ( array_keys( $settings['feeds'] ) as $feed_id ) {
			$feed = djfi_get_feed( (string) $feed_id );
			if ( $feed && ! empty( $feed['enabled'] ) && ! empty( $feed['url'] ) ) {
				DJFI_Importer::start( $feed );
				wp_schedule_single_event( time() + 5, 'djfi_continue', array( (string) $feed_id ) );
			}
		}
	}
);

add_action(
	'djfi_continue',
	static function ( $feed_id ) {
		$state = DJFI_Importer::step( (string) $feed_id );
		if ( $state && 'done' !== $state['phase'] && 'error' !== $state['phase'] ) {
			wp_schedule_single_event( time() + 10, 'djfi_continue', array( (string) $feed_id ) );
		}
	}
);

if ( is_admin() ) {
	DJFI_Admin::init();
}
