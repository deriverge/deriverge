=== Deriverge Job Feed Importer for WP Job Manager ===
Contributors: deriverge
Tags: job feed, job import, wp job manager, xml feed, backfill
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Import jobs from an XML, JSON or JSON Lines feed into WP Job Manager on a schedule. Updates changed jobs and expires the ones that left the feed.

== Description ==

This plugin fills a WP Job Manager job board from a job feed and keeps it current. You give it the address of a feed, and it creates a job listing for every job, updates the listings whose jobs changed and closes the ones that are no longer in the feed.

It works with any feed in these formats:

* **XML** with one `<job>` element per job (the common job feed layout with `title`, `company`, `url`, `description` and so on), or an RSS feed with `<item>` elements
* **JSON Lines**, one job per line
* **JSON**, an array of jobs
* any of the above compressed with gzip

= What it does =

* Imports on a schedule: once a day, twice a day or every hour, or only when you press Run now
* Reads large feeds in small batches, so an import of thousands of jobs does not hit the time limit of your hosting
* Recognises a job it imported before and does not create it twice
* Updates a listing only when its job changed in the feed
* When a job leaves the feed: marks the listing as expired, marks it as filled, moves it to the trash or leaves it, your choice
* Never closes anything when the feed is empty or cannot be reached
* Does not bring back a listing you moved to the trash yourself
* Fills the WP Job Manager fields: location, application link, company name and website, remote position, salary with currency and unit
* Sets the job type (full time, part time, freelance, temporary, internship) from the many ways feeds spell it
* Sets the job category and creates categories that do not exist yet
* New jobs can be published right away or saved as pending for your approval
* Several feeds at once, each with its own settings
* A log of recent imports: how many jobs were read, created, updated and closed

Everything is in the plugin. There is no paid version of the plugin and no feature is locked.

= Where to get a feed =

Any feed you have the right to use works: a feed from an employer, from an applicant tracking system, from a job network or from a data provider.

The form also offers a small free sample feed, so you can try the import before you have a feed of your own.

The plugin is made by deriverge, a company that also sells job data feeds: jobs collected from public company career sites, by country or by niche, delivered every day. That is a separate paid service and it is optional; the plugin does not need it. Details are at [deriverge.com/tools/job-data-feed/](https://deriverge.com/tools/job-data-feed/).

= For developers =

* `djfi_job` filters a job before it is written. Return `false` to skip it.
* `djfi_job_saved` fires after a listing was created or updated.
* `djfi_batch_jobs` and `djfi_batch_seconds` set how much work one batch does.
* `djfi_max_feed_bytes` sets the largest feed file the plugin downloads.

== External services ==

The plugin downloads the feed from the address you enter. This is the only connection it makes, and it makes it when an import runs: on the schedule you chose or when you press Run now. The request carries the plugin name and version and the address of your site in the User-Agent header, the way WordPress identifies itself in its own requests. No data about your visitors or your users is sent.

Which server receives the request depends on the feed address you entered:

* **A feed of your own choice.** The request goes to whoever hosts that feed, under their terms.
* **The free sample feed**, if you choose it in the form: a static file at `https://deriverge.com/tools/data/job-feed-sample.xml`, provided by deriverge s.r.o. [Terms](https://deriverge.com/tools/job-data-feed/terms/), [data sources and privacy](https://deriverge.com/tools/job-data-feed/data-and-privacy/).
* **A paid deriverge job data feed**, if you subscribe to one: its files are served from `api.apify.com`, the storage of Apify Technologies s.r.o., at a private address that deriverge sends you. deriverge [terms](https://deriverge.com/tools/job-data-feed/terms/) and [privacy](https://deriverge.com/tools/job-data-feed/data-and-privacy/); Apify [terms](https://apify.com/terms-of-use) and [privacy policy](https://apify.com/privacy-policy).

The plugin does not contact any server until you have added a feed.

== Installation ==

1. Install and activate WP Job Manager.
2. Install and activate this plugin.
3. Go to Job Manager, Feed Import (Job Listings, Feed Import in older versions of WP Job Manager).
4. Enter the address of your feed, choose what happens to new jobs and to jobs that leave the feed, and add the feed.
5. Press Run now for the first import. After that the feed is imported on the schedule.

== Frequently Asked Questions ==

= Which feed fields does it read? =

In XML: `title`, `company`, `url`, `applyurl`, `description`, `location` (or `city`, `state`, `country`), `referencenumber`, `date`, `jobtype`, `category`, `salary` or `salarymin`, `salarymax`, `salarycurrency` and `salaryperiod`, `remotetype` or `workarrangement`, `companywebsite`. In JSON the same information under the usual names, for example `title`, `company`, `location`, `url`, `applyUrl`, `descriptionHtml` or `description`, `employmentType`, `jobCategory`, `salaryMin`, `salaryMax`, `workArrangement`. Field names are matched without regard to upper and lower case.

= How does it know a job was imported before? =

By the job's id in the feed (`referencenumber` in XML, `id` in JSON). When a feed has no id, the job's address is used.

= My feed has 20,000 jobs. Will the import time out? =

No. The import runs in batches of a few seconds each and continues where it stopped. With Run now the page shows the progress; scheduled imports continue in the background through WP-Cron.

= The scheduled import did not run =

WP-Cron runs when somebody visits the site. On a site with few visitors, set up a real cron job that calls `wp-cron.php`, which your hosting's documentation describes.

= What happens to the jobs when I delete a feed or the plugin? =

They stay. They are ordinary WP Job Manager listings and belong to your site.

= Does it import company logos? =

Not in this version. The logo address from the feed is available to developers in the `djfi_job_saved` action.

= Does the plugin add links or credits to my site? =

No. It adds nothing to the public pages of your site.

== Screenshots ==

1. Adding a feed: the address and what happens to new jobs and to jobs that leave the feed.
2. The list of feeds with the result of the last import, Run now and the schedule.

== Changelog ==

= 1.0.0 =
* First release.
